Academicons
===========
Academicons is an icon font for academics. It aims to supplement other packages (such as Font Awesome) with icons for academic websites. Go to http://jpswalsh.github.io/academicons to view the full icon set along with instructions for their use.

## License
- The Academicons font is licensed under the SIL OFL 1.1:
  - http://scripts.sil.org/OFL
- Academicons CSS, LESS, and SASS files are licensed under the MIT License:
  - http://opensource.org/licenses/mit-license.html
- The Academicons documentation is licensed under the CC BY 3.0 License:
  - http://creativecommons.org/licenses/by/3.0/

## Author
- GitHub: https://github.com/jpswalsh
- Web: http://jpswalsh.com
